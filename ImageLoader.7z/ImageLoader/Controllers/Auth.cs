﻿using System.Text;
using System.Net.Http.Headers;

using Newtonsoft.Json;
using Efir.DataHub.Models.Models.Info;
using Efir.DataHub.Models.Requests.V2.Info;
using Efir.DataHub.Models.Models.Account;
using Efir.DataHub.Models.Requests.V2.Account;

 

namespace ImageLoader.Controllers
{

    public class Auth

    {

        private string Url { get; }

        private string Login { get; }

        private string Password { get; }



        public static async Task DoTest()

        {

            var example = new Auth("https://dh2.efir-net.ru/v2", "expobank-api1", "731Klr");

            var token = await example.LoginAsync();



            Console.WriteLine($"Token: {token}");



            var data = await example.GetBondsByEmitentAsync(6496, token);



            Console.WriteLine($"Data: {JsonConvert.SerializeObject(data)}");

        }



        public Auth(string url, string login, string password)

        {

            Url = url;

            Login = login;

            Password = password;

        }



        public async Task<string> LoginAsync()

        {

            var query = new LoginRequest

            {

                login = Login,

                password = Password

            };

            var res = await ApiPostRequestAsync<LoginRequest, LoginResponse>($"{Url}/account/login", query);



            return res?.Token;

        }



        public async Task<List<FintoolReferenceDataFields>> GetBondsByEmitentAsync(long issuerId, string token)

        {

            var query = new FintoolReferenceDataRequest

            {

                filter = $"ISSUERUID={issuerId} AND FINTOOLTYPE IN ('Облигация')"

            };

            return await ApiPostRequestAsync<FintoolReferenceDataRequest, List<FintoolReferenceDataFields>>($"{Url}/info/fintoolReferenceData", query, token);

        }



        private static async Task<Response> ApiPostRequestAsync<Request, Response>(string url, Request request, string token = null)

        {

            var client = new HttpClient();

            client.DefaultRequestHeaders.Add("Accept", "application/json");

            if (!string.IsNullOrEmpty(token)) client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);



            var jsonData = JsonConvert.SerializeObject(request);

            var response = await client.PostAsync(url, new StringContent(jsonData, Encoding.UTF8, "application/json"));



            if (!response.IsSuccessStatusCode) //error

                throw new System.Exception("api error");



            return await response.Content.ReadAsAsync<Response>();

        }



    }

}